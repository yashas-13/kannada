import torch
from transformers import VitsModel, AutoTokenizer
import scipy.io.wavfile
import numpy as np

def test_tts():
    try:
        print("Loading VITS model for Kannada...")
        # Try 'facebook/mms-tts-kan' first
        model_id = "facebook/mms-tts-kan"
        model = VitsModel.from_pretrained(model_id)
        tokenizer = AutoTokenizer.from_pretrained(model_id)
        
        text = "ನಮಸ್ಕಾರ, ನೀವು ಹೇಗಿದ್ದೀರಿ?" # Hello, how are you?
        print(f"Generating audio for: {text}")
        
        inputs = tokenizer(text, return_tensors="pt")
        
        with torch.no_grad():
            output = model(**inputs).waveform
        
        # Save to file
        waveform = output.cpu().numpy().squeeze()
        scipy.io.wavfile.write("test_kan.wav", model.config.sampling_rate, waveform)
        print("Audio saved to test_kan.wav")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_tts()
