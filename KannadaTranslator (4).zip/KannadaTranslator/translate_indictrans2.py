import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

# NOTE: IndicTrans2 models are larger and provide better quality for Indian languages.
# You might need to install additional dependencies or use specific revision branches if instructed by their repo.
# Standard usage usually works with recent transformers versions.

class IndicTranslator:
    def __init__(self, direction="en-indic"):
        # direction can be 'en-indic' or 'indic-en'
        # ai4bharat/indictrans2-en-indic-1B
        # ai4bharat/indictrans2-indic-en-1B
        
        self.direction = direction
        if direction == "en-indic":
            self.model_name = "ai4bharat/indictrans2-en-indic-1B"
        else:
            self.model_name = "ai4bharat/indictrans2-indic-en-1B"
            
        print(f"Loading IndicTrans2 model: {self.model_name}...")
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # trust_remote_code=True might be needed depending on the specific model version, 
        # but the 1B models on HF often work out of the box with recent transformers.
        # However, AI4Bharat often recommends using their custom inference scripts or trust_remote_code=True.
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name, trust_remote_code=True)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(self.model_name, trust_remote_code=True).to(self.device)
        print("Model loaded.")

    def translate(self, text, src_lang, tgt_lang):
        # IndicTrans2 language codes are usually 3 letters or specific codes.
        # For English: 'eng_Latn'
        # For Kannada: 'kan_Knda' 
        # (They align with NLLB codes mostly in the newer versions)
        
        # Tokenization might need specific handling for IndicTrans2
        inputs = self.tokenizer(text, src_lang=src_lang, tgt_lang=tgt_lang, return_tensors="pt", padding=True).to(self.device)
        
        with torch.no_grad():
            generated_tokens = self.model.generate(
                **inputs,
                use_cache=True,
                min_length=0,
                max_length=512,
                num_beams=5,
                num_return_sequences=1,
            )
            
        # Decode
        translation = self.tokenizer.batch_decode(generated_tokens, skip_special_tokens=True)[0]
        return translation

def main():
    print("--- IndicTrans2 Example (English to Kannada) ---")
    # This requires downloading the en-indic model (~4GB)
    try:
        translator = IndicTranslator("en-indic")
        text = "Building a translator is an exciting project."
        print(f"Input: {text}")
        translation = translator.translate(text, src_lang="eng_Latn", tgt_lang="kan_Knda")
        print(f"Translation: {translation}")
    except Exception as e:
        print(f"Error loading/running IndicTrans2: {e}")
        print("Note: This model is large and requires 'trust_remote_code=True'.")

if __name__ == "__main__":
    main()
