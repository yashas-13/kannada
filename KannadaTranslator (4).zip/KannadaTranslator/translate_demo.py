import sys
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer, NllbTokenizer
import torch

class Translator:
    def __init__(self, model_name="facebook/nllb-200-distilled-600M"):
        print(f"Loading model: {model_name}...")
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"Using device: {self.device}")
        
        self.model_name = model_name
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name).to(self.device)
        print("Model loaded successfully.")

    def translate(self, text, src_lang, tgt_lang):
        """
        Translate text from src_lang to tgt_lang.
        For NLLB, language codes are like 'eng_Latn', 'kan_Knda'.
        """
        # Ensure we are using the correct language codes for NLLB
        # Mapping common names to NLLB codes if needed, or user provides them directly
        
        inputs = self.tokenizer(text, return_tensors="pt", padding=True, truncation=True).to(self.device)
        
        # NLLB requires forcing the BOS token for the target language
        # For NLLB, we need to set the target language in the generate call
        # But wait, AutoTokenizer for NLLB usually handles src_lang via tokenizer.src_lang
        
        # Set source language
        self.tokenizer.src_lang = src_lang
        
        # Generate translation
        # forced_bos_token_id is crucial for NLLB to know target language
        translated_tokens = self.model.generate(
            **inputs, 
            forced_bos_token_id=self.tokenizer.convert_tokens_to_ids(tgt_lang), 
            max_length=100
        )
        
        result = self.tokenizer.batch_decode(translated_tokens, skip_special_tokens=True)[0]
        return result

def main():
    # NLLB Codes:
    # English: eng_Latn
    # Kannada: kan_Knda
    
    print("Initializing Translator (this may take a moment to download the model)...")
    translator = Translator()
    
    print("\n--- English to Kannada Translation ---")
    text_en = "Hello, how are you doing today?"
    print(f"Input (English): {text_en}")
    trans_kn = translator.translate(text_en, src_lang="eng_Latn", tgt_lang="kan_Knda")
    print(f"Output (Kannada): {trans_kn}")
    
    print("\n--- Kannada to English Translation ---")
    text_kn = "ನಮಸ್ಕಾರ, ನೀವು ಹೇಗಿದ್ದೀರಿ?" # Namaskara, nivu hegiddiri?
    print(f"Input (Kannada): {text_kn}")
    trans_en = translator.translate(text_kn, src_lang="kan_Knda", tgt_lang="eng_Latn")
    print(f"Output (English): {trans_en}")

    print("\nDone!")

if __name__ == "__main__":
    main()
