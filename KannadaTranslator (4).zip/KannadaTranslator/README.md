# Kannada AI Assistant

This is a Flask web application that acts as a frontend for a local Kannada LLM (`gemma-kannada-instruct`) running at `http://192.168.80.1:1234`.

## Features
- **Chat Mode**: General conversation with the AI.
- **Translation Mode**: Specialized prompts for English -> Kannada and Kannada -> English translation.
- **Local Only**: Does not rely on external APIs (except for Bootstrap CDN, which is cached by browsers).

## Prerequisites
1. Ensure your local LLM server is running at `http://192.168.80.1:1234`.
2. Python 3.8+ installed.

## Installation

```bash
pip install -r requirements.txt
```

## Running the App

```bash
python app.py
```

Open your browser and navigate to `http://localhost:5000`.

## Configuration
To change the LLM endpoint or model name, edit `app.py`:

```python
LLM_API_URL = "http://192.168.80.1:1234/v1/chat/completions"
MODEL_NAME = "gemma-kannada-instruct"
```
